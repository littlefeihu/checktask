package com.lexisnexis.printext;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;

import android.print.PrintAttributes;

public class Helper {
	public static PrintAttributes createPrintAttributes()
	{
		Class<?> paClass = null;
    	try
    	{
    		paClass = Class.forName("android.print.PrintAttributes");
    		Constructor<?> cons = paClass.getDeclaredConstructor(new Class[]{});
    		cons.setAccessible(true);
    		return (PrintAttributes)cons.newInstance(new Object[0]);
    	}
    	catch(Exception e)
    	{
    		e.printStackTrace();
    	}
    	
    	return null;
	}
	
	public static PrintAttributes.MediaSize smallMediaSize(PrintAttributes.MediaSize orginal)
	{
		Class<?> msClass = null;
    	try
    	{
    		msClass = Class.forName("android.print.PrintAttributes$MediaSize");
    		Field packageName = msClass.getDeclaredField("mPackageName");
    		packageName.setAccessible(true);
    		
    		Field labelResId = msClass.getDeclaredField("mLabelResId");
    		labelResId.setAccessible(true);
    		
    		android.util.Log.d("dbg", "HeightMils = " + orginal.getHeightMils());
    		return new PrintAttributes.MediaSize(
    				orginal.getId(),
    				(String)packageName.get(orginal),
    				labelResId.getInt(orginal),
    				orginal.getWidthMils(),
    				orginal.getHeightMils() - getHeightHeaderFooterTotal(1000));
    	}
    	catch(Exception e)
    	{
    		e.printStackTrace();
    	}
    	
    	return null;
	}
	
	public static final int HeightHeaderFooterTotal = 1; // inch
	
	public static int getHeightHeaderFooterTotal(int dpi)
	{
		return HeightHeaderFooterTotal * dpi;
	}
	
	public static PrintAttributes.MediaSize largeMediaSize(PrintAttributes.MediaSize orginal)
	{
		Class<?> msClass = null;
    	try
    	{
    		msClass = Class.forName("android.print.PrintAttributes$MediaSize");
    		Field packageName = msClass.getDeclaredField("mPackageName");
    		packageName.setAccessible(true);
    		
    		Field labelResId = msClass.getDeclaredField("mLabelResId");
    		labelResId.setAccessible(true);
    		
    		return new PrintAttributes.MediaSize(
    				orginal.getId(),
    				(String)packageName.get(orginal),
    				labelResId.getInt(orginal),
    				orginal.getWidthMils(),
    				orginal.getWidthMils());
    	}
    	catch(Exception e)
    	{
    		e.printStackTrace();
    	}
    	
    	return null;
	}
}
