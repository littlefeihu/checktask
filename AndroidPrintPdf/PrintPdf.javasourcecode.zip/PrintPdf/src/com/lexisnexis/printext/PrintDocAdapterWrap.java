package com.lexisnexis.printext;

//import com.kenny.FakeLayoutResultCallback;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.ParcelFileDescriptor;
import android.print.PageRange;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintDocumentInfo;

@SuppressLint("WrongCall")
public class PrintDocAdapterWrap extends PrintDocumentAdapter
{
	public static class LayoutResultCallbackWrap extends PrintDocumentAdapter.LayoutResultCallback
	{
		private PrintDocumentAdapter.LayoutResultCallback callback;
		private PrintLayoutResultCallback customCallback;
		
		public LayoutResultCallbackWrap(PrintDocumentAdapter.LayoutResultCallback callback) {
			super();
			this.callback = callback;
		}
		
		public LayoutResultCallbackWrap(PrintLayoutResultCallback callback) {
			super();
			this.customCallback = callback;
		}
		
		@Override
        public void onLayoutFinished(PrintDocumentInfo info, boolean changed) {
            android.util.Log.d("dbg", "onLayoutFinished");
            if(callback != null)
            {
            	callback.onLayoutFinished(info, changed);
            }
            
            if(customCallback != null)
            {
            	customCallback.onLayoutFinished(info, changed);
            }
        }
		
		@Override
        public void onLayoutFailed(CharSequence error) {
			android.util.Log.d("dbg", "onLayoutFailed");
			if(callback != null)
            {
				callback.onLayoutFailed(error);
            }
			
            if(customCallback != null)
            {
            	customCallback.onLayoutFailed(error);
            }
        }

		@Override
        public void onLayoutCancelled() {
			android.util.Log.d("dbg", "onLayoutCancelled");
			if(callback != null)
            {
				callback.onLayoutCancelled();
            }
			
            if(customCallback != null)
            {
            	customCallback.onLayoutCancelled();
            }
        }
	}
	
	public static class WriteResultCallbackWrap extends PrintDocumentAdapter.WriteResultCallback
	{
		private PrintDocumentAdapter.WriteResultCallback callback;
		private PrintWriteResultCallback customCallback;
		
        public WriteResultCallbackWrap(PrintDocumentAdapter.WriteResultCallback callback)
        {
        	super();
            this.callback = callback;
        }
        
		public WriteResultCallbackWrap(PrintWriteResultCallback callback) {
			super();
			this.customCallback = callback;
		}

        public void onWriteFinished(PageRange[] pages) {
        	android.util.Log.d("dbg", "onWriteFinished");
        	if(callback != null)
            {
        		callback.onWriteFinished(pages);
            }
        	
            if(customCallback != null)
            {
            	customCallback.onWriteFinished(pages);
            }
        }

        public void onWriteFailed(CharSequence error) {
        	android.util.Log.d("dbg", "onWriteFailed");
        	if(callback != null)
            {
        		callback.onWriteFailed(error);
            }
        	
            if(customCallback != null)
            {
            	customCallback.onWriteFailed(error);
            }
        }

        public void onWriteCancelled() {
        	android.util.Log.d("dbg", "onWriteCancelled");
        	if(callback != null)
            {
        		callback.onWriteCancelled();
            }
        	
            if(customCallback != null)
            {
            	customCallback.onWriteCancelled();
            }
        }
    }
	
	private PrintDocumentAdapter acturalAdapter;
	private PrintDocumentAdapter.LayoutResultCallback callback;
	
	public PrintDocAdapterWrap(PrintDocumentAdapter acturalAdapter) {
		super();
		this.acturalAdapter = acturalAdapter;
	}

	@Override
	public void onStart() {
		super.onStart();
		this.acturalAdapter.onStart();
	}

	@Override
	public void onFinish() {
		super.onFinish();
		
		this.acturalAdapter.onFinish();
	}

	@Override
	public void onLayout(PrintAttributes oldAttributes,
			PrintAttributes newAttributes,
			CancellationSignal cancellationSignal,
			LayoutResultCallback callback, Bundle extras) {
		
		this.acturalAdapter.onLayout(oldAttributes, newAttributes, cancellationSignal, new LayoutResultCallbackWrap(callback), extras);
	}

	@Override
	public void onWrite(PageRange[] pages, ParcelFileDescriptor destination,
			CancellationSignal cancellationSignal, WriteResultCallback callback) {
		this.acturalAdapter.onWrite(pages, destination, cancellationSignal, new WriteResultCallbackWrap(callback));
	}

}
