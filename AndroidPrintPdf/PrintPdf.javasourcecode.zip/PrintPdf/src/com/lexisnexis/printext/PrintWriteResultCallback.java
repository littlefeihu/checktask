package com.lexisnexis.printext;

import android.print.PageRange;

public interface PrintWriteResultCallback {
    void onWriteFinished(PageRange[] pages);
    void onWriteFailed(CharSequence error);
    void onWriteCancelled();
}
