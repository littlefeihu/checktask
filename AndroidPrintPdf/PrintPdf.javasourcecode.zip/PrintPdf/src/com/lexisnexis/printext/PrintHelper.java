package com.lexisnexis.printext;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.lang.reflect.Constructor;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.ParcelFileDescriptor;
import android.print.PageRange;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;

@SuppressLint("WrongCall")
public class PrintHelper {
	public static void layout(
			PrintDocumentAdapter adapter,
			CancellationSignal cancellationSignal,
			PrintLayoutResultCallback callback)
	{
		PrintAttributes opa = Helper.createPrintAttributes();
		PrintAttributes npa = Helper.createPrintAttributes();
		//npa.setMediaSize(Helper.smallMediaSize(PrintAttributes.MediaSize.ISO_A4));
		npa.setMediaSize(PrintAttributes.MediaSize.ISO_A4);
		npa.setResolution(new PrintAttributes.Resolution("PDF resolution", "PDF resolution", 300, 300));
		npa.setMinMargins(new PrintAttributes.Margins(0, 0, 0, 0));
		npa.setColorMode(PrintAttributes.COLOR_MODE_COLOR);
		
		adapter.onLayout(
				opa,
				npa,
				cancellationSignal,
				new PrintDocAdapterWrap.LayoutResultCallbackWrap(callback),
				null);
	}
	
	public static void smallSizeLayout(
			PrintDocumentAdapter adapter,
			CancellationSignal cancellationSignal,
			PrintLayoutResultCallback callback)
	{
		PrintAttributes opa = Helper.createPrintAttributes();
		PrintAttributes npa = Helper.createPrintAttributes();
		npa.setMediaSize(Helper.smallMediaSize(PrintAttributes.MediaSize.ISO_A4));
		npa.setResolution(new PrintAttributes.Resolution("PDF resolution", "PDF resolution", 300, 300));
		npa.setMinMargins(new PrintAttributes.Margins(0, 0, 0, 0));
		npa.setColorMode(PrintAttributes.COLOR_MODE_COLOR);
		
		adapter.onLayout(
				opa,
				npa,
				cancellationSignal,
				new PrintDocAdapterWrap.LayoutResultCallbackWrap(callback),
				null);
	}
	
	public static void layout(
			PrintDocumentAdapter adapter,
			PrintAttributes oldAttributes,
			PrintAttributes newAttributes,
            CancellationSignal cancellationSignal,
            PrintLayoutResultCallback callback,
            Bundle extras)
	{
		adapter.onLayout(
				oldAttributes,
				newAttributes,
				cancellationSignal,
				new PrintDocAdapterWrap.LayoutResultCallbackWrap(callback),
				extras);
	}
	
	public static void write(
			PrintDocumentAdapter adapter,
			PageRange[] pages,
			String destinationFullPath,
            CancellationSignal cancellationSignal,
            PrintWriteResultCallback callback) throws IOException
	{
		File destination = new File(destinationFullPath);
		if(destination.exists())
		{
			destination.delete();
		}
		
		destination.createNewFile();
		ParcelFileDescriptor parcelFileDescriptor = null;
		parcelFileDescriptor = ParcelFileDescriptor.open(destination, ParcelFileDescriptor.MODE_READ_WRITE);

		adapter.onWrite(
				pages,
				parcelFileDescriptor,
				cancellationSignal,
				new PrintDocAdapterWrap.WriteResultCallbackWrap(callback));
	}
}
