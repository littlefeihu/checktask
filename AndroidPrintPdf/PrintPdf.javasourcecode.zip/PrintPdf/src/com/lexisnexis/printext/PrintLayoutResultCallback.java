package com.lexisnexis.printext;

import android.print.PrintDocumentInfo;

public interface PrintLayoutResultCallback {
	void onLayoutFinished(PrintDocumentInfo info, boolean changed);
    void onLayoutFailed(CharSequence error);
    void onLayoutCancelled();
}
